# 国际化 (Localization) 说明

## 概述
TrustMacApp 现在支持中文和英文两种语言。应用会根据系统语言设置自动选择显示语言。

## 支持的语言
- 中文 (简体) - `zh-Hans.lproj`
- 英文 - `en.lproj`

## 文件结构
```
TrustMacApp/
├── en.lproj/
│   ├── Localizable.strings    # 代码英文本地化字符串
│   └── InfoPlist.strings      # Info.plist 英文本地化
├── zh-Hans.lproj/
│   ├── Localizable.strings    # 代码中文本地化字符串
│   └── InfoPlist.strings      # Info.plist 中文本地化
└── LocalizationTest.swift     # 国际化测试文件
```

## 使用方法

### 在代码中使用本地化字符串
```swift
// 使用 NSLocalizedString 函数
let tutorialText = NSLocalizedString("Tutorial", comment: "Menu item for tutorial")
let quitText = NSLocalizedString("Quit", comment: "Menu item for quitting the app")
```

### 添加新的本地化字符串
1. 在 `en.lproj/Localizable.strings` 中添加英文版本
2. 在 `zh-Hans.lproj/Localizable.strings` 中添加中文版本
3. 在代码中使用 `NSLocalizedString` 函数

### 测试国际化
应用在 DEBUG 模式下会自动运行国际化测试，输出当前语言和本地化字符串。

## 当前已国际化的内容

### FinderSync 扩展
- 工具栏项目名称和提示
- 右键菜单项：信任并打开、打开Data目录

### 主应用
- 菜单项：教程、退出
- 调试信息：Shell 命令输出和错误信息
- 应用信息：应用名称、关于、偏好设置、帮助等

## 添加新语言支持
1. 创建新的 `.lproj` 目录（如 `ja.lproj` 用于日语）
2. 复制 `Localizable.strings` 文件到新目录
3. 翻译所有字符串为对应语言

## 注意事项
- 确保所有硬编码的文本都使用 `NSLocalizedString` 函数
- 为每个本地化字符串添加有意义的注释
- 测试不同语言环境下的显示效果 